package com.employee.employeecrud.respirotory;

import com.employee.employeecrud.entity.Employeeentity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRespirotary extends JpaRepository<Employeeentity, Long> {


}
