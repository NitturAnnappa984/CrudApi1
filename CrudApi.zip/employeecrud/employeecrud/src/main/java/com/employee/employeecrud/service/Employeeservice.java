package com.employee.employeecrud.service;

import com.employee.employeecrud.entity.Employeeentity;
import com.employee.employeecrud.respirotory.EmployeeRespirotary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;


import java.util.List;

@Service
public class Employeeservice {
    @Autowired
    private EmployeeRespirotary employeeRepository;
    public Employeeentity addEmployee(Employeeentity employee) {
        return employeeRepository.save(employee);
    }

    public List<Employeeentity> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Employeeentity getEmployeeById(Long id) {
        return employeeRepository.findById(id)
                .orElseThrow(() ->
                        new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "Employee not found with id " + id
                        )
                );
    }
    public Employeeentity updateEmployee(Long id, Employeeentity employee) {
        employee.setId(id);
        return employeeRepository.save(employee);
    }
    public void deleteEmployee(Long id) {

        if (!employeeRepository.existsById(id)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND,
                    "Employee not found with id " + id
            );
        }

        employeeRepository.deleteById(id);
    }


}
