package com.employee.employeecrud.controller;

import com.employee.employeecrud.entity.Employeeentity;
import com.employee.employeecrud.service.Employeeservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/employees")

public class EmployeeController {
    @Autowired
    private Employeeservice employeeservice;
    @PostMapping
    public Employeeentity addEmployee(@RequestBody Employeeentity employee) {
        return employeeservice.addEmployee(employee);
    }

    // READ ALL
    @GetMapping
    public List<Employeeentity> getAllEmployees() {
        return employeeservice.getAllEmployees();
    }

    // READ BY ID
    @GetMapping("/{id}")
    public Employeeentity getEmployeeById(@PathVariable Long id) {
        return employeeservice.getEmployeeById(id);
    }

    // UPDATE
    @PutMapping("/{id}")
    public Employeeentity updateEmployee(@PathVariable Long id,
                                         @RequestBody Employeeentity employee) {
        return employeeservice.updateEmployee(id, employee);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteEmployee(@PathVariable Long id) {
        employeeservice.deleteEmployee(id);
        return "Employee deleted successfully";
    }

}
