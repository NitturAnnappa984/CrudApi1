package com.employee.employeecrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeecrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
